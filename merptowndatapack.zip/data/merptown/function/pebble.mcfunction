execute unless block ~ ~0.5 ~ minecraft:stone_button run return run advancement revoke @s only merptown:pebble
damage @s 2 minecraft:generic
title @s title "You tripped."
effect give @s minecraft:slowness 1 4 true
execute anchored eyes positioned ^ ^ ^ positioned ~ ~-0.3 ~ run loot spawn ~ ~ ~ loot merptown:mainhand
execute anchored eyes positioned ^ ^ ^ positioned ~ ~-0.3 ~ run data merge entity @n[type=minecraft:item] {PickupDelay:40}
item replace entity @s weapon.mainhand with minecraft:air
fill ~ ~-1 ~ ~ ~1 ~ air replace minecraft:stone_button
advancement revoke @s only merptown:pebble