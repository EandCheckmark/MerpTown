execute unless block ~ ~0.5 ~ minecraft:light_weighted_pressure_plate run return run advancement revoke @s only merptown:stunner
scoreboard players set @s stun 50
playsound minecraft:block.anvil.land block @s ~ ~ ~ 100 1 1
title @s title {text:"You are stunned.",color:"dark_red"}
effect give @s minecraft:blindness 2 0 true
fill ~ ~-1 ~ ~ ~1 ~ air replace minecraft:light_weighted_pressure_plate
advancement revoke @s only merptown:stunner