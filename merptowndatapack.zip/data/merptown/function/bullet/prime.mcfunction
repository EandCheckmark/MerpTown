execute if items entity @s contents *[minecraft:custom_data~{Fire:1b}] run tag @s add fire
execute if items entity @s contents *[minecraft:custom_data~{Pierce:1b}] run tag @s add pierce
data merge entity @s {NoGravity:1b,crit:0b}
execute if entity @s[tag=fire] run data merge entity @s {Fire:32767}
execute if entity @s[tag=pierce] run data merge entity @s {PierceLevel:10b}

execute if data entity @s weapon.components."minecraft:custom_data"{Accurate:1b} run return run function merptown:bullet/normalize/accurate
function merptown:bullet/normalize/inaccurate