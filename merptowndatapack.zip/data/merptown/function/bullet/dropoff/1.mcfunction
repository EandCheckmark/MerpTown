data modify storage merptown:bullet velocity set from entity @s Motion
execute store result storage merptown:bullet velocity[0] double 0.0001 run data get storage merptown:bullet velocity[0] 9797
execute store result storage merptown:bullet velocity[1] double 0.0001 run data get storage merptown:bullet velocity[1] 9797
execute store result storage merptown:bullet velocity[2] double 0.0001 run data get storage merptown:bullet velocity[2] 9797
data modify entity @s Motion set from storage merptown:bullet velocity