execute store result storage merptown:bullet velocity[0] double 0.0001 run data get storage merptown:bullet velocity[0] 9494
execute store result storage merptown:bullet velocity[1] double 0.0001 run data get storage merptown:bullet velocity[1] 9494
execute store result storage merptown:bullet velocity[2] double 0.0001 run data get storage merptown:bullet velocity[2] 9494
data modify entity @s Motion set from storage merptown:bullet velocity