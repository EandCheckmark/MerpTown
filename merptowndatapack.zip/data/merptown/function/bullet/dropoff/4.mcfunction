execute store result storage merptown:bullet velocity[0] double 0.0001 run data get storage merptown:bullet velocity[0] 7676
execute store result storage merptown:bullet velocity[1] double 0.0001 run data get storage merptown:bullet velocity[1] 7676
execute store result storage merptown:bullet velocity[2] double 0.0001 run data get storage merptown:bullet velocity[2] 7676
data modify entity @s Motion set from storage merptown:bullet velocity