execute store result storage merptown:bullet velocity[0] double 0.0001 run data get storage merptown:bullet velocity[0] 10101
execute store result storage merptown:bullet velocity[1] double 0.0001 run data get storage merptown:bullet velocity[1] 10101
execute store result storage merptown:bullet velocity[2] double 0.0001 run data get storage merptown:bullet velocity[2] 10101
data modify entity @s Motion set from storage merptown:bullet velocity