$execute positioned ~$(particlex1) ~$(particley1) ~$(particlez1) run function merptown:bullet/particle
$execute positioned ~$(particlex2) ~$(particley2) ~$(particlez2) run function merptown:bullet/particle
$execute positioned ~$(particlex3) ~$(particley3) ~$(particlez3) run function merptown:bullet/particle