particle minecraft:copper_fire_flame ~ ~ ~ 0 0 0 0 1 force
execute if entity @s[tag=fire] run particle minecraft:flame ~ ~ ~ 0 0 0 0.05 1 force
execute if entity @s[tag=pierce] run particle minecraft:glow ~ ~ ~ 0 0 0 0 1 force