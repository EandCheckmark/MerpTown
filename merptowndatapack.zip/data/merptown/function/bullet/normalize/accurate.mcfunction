execute on origin rotated as @s positioned 0.0 0 0.0 run summon minecraft:marker ^ ^ ^7.9 {Tags:["accuracy"]}
data modify entity @s Motion set from entity @e[type=minecraft:marker,tag=accuracy,limit=1] Pos
kill @e[type=minecraft:marker,tag=accuracy]