execute rotated as @s positioned 0.0 0 0.0 positioned ^ ^ ^2 positioned 0.0 0 ~ positioned ^ ^ ^-1 facing 0.0 0 0.0 facing ^ ^ ^-1 positioned 0.0 0 0.0 run summon minecraft:marker ^ ^ ^7.9 {Tags:["normalize"]}
data modify entity @s Motion set from entity @e[type=minecraft:marker,tag=normalize,limit=1] Pos
kill @e[type=minecraft:marker,tag=normalize]