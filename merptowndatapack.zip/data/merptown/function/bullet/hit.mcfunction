execute rotated as @s positioned 0.0 0 0.0 positioned ^ ^ ^2 positioned 0.0 0 ~ positioned ^ ^ ^-1 facing 0.0 0 0.0 facing ^ ^ ^-1 positioned as @s if block ^ ^ ^0.1 #merptown:bullet_breakable run setblock ^ ^ ^0.1 air destroy
execute at @s run particle minecraft:copper_fire_flame ~ ~ ~ 0 0 0 0 1 force
kill @s