execute rotated as @s positioned 0.0 0 0.0 positioned ^ ^ ^2 positioned 0.0 0 ~ positioned ^ ^ ^-1 facing 0.0 0 0.0 facing ^ ^ ^-1 positioned as @s if block ^ ^ ^0.1 #merptown:bullet_breakable run setblock ^ ^ ^0.1 air destroy
execute at @s run function merptown:bullet/particle
data modify storage merptown:bullet position set from entity @s Pos
execute store result score @s bulletHitX run data get storage merptown:bullet position[0] 100
execute store result score @s bulletHitY run data get storage merptown:bullet position[1] 100
execute store result score @s bulletHitZ run data get storage merptown:bullet position[2] 100
scoreboard players operation @s bulletX -= @s bulletHitX
scoreboard players operation @s bulletY -= @s bulletHitY
scoreboard players operation @s bulletZ -= @s bulletHitZ
data modify storage merptown:bullet velocity set from entity @s Motion
execute store result storage merptown:bullet particlex1 double 0.0025 run scoreboard players get @s bulletX
execute store result storage merptown:bullet particley1 double 0.0025 run scoreboard players get @s bulletY
execute store result storage merptown:bullet particlez1 double 0.0025 run scoreboard players get @s bulletZ
execute store result storage merptown:bullet particlex2 double 0.005 run scoreboard players get @s bulletX
execute store result storage merptown:bullet particley2 double 0.005 run scoreboard players get @s bulletY
execute store result storage merptown:bullet particlez2 double 0.005 run scoreboard players get @s bulletZ
execute store result storage merptown:bullet particlex3 double 0.0075 run scoreboard players get @s bulletX
execute store result storage merptown:bullet particley3 double 0.0075 run scoreboard players get @s bulletY
execute store result storage merptown:bullet particlez3 double 0.0075 run scoreboard players get @s bulletZ
execute at @s run function merptown:bullet/particlemacro with storage merptown:bullet
kill @s