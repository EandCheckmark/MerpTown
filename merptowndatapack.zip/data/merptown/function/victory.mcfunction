title @s title {text:"VICTORY",color:"aqua",bold:true}
execute anchored eyes run particle minecraft:totem_of_undying ^ ^ ^ 0 0 0 0.5 100 force
playsound minecraft:ui.toast.challenge_complete master @a ~ ~ ~
effect give @s minecraft:resistance infinite 4 true
scoreboard players set @s victory 1
scoreboard players set [timer] timer 0
scoreboard players set [active] active 0