execute unless block ~ ~0.5 ~ minecraft:polished_blackstone_pressure_plate run return run advancement revoke @s only merptown:mine
summon minecraft:wolf ~ ~ ~ {Silent:1b,Invulnerable:1b,DeathLootTable:"minecraft:empty",NoAI:1b,Tags:["mine"],CustomName:"Mine",equipment:{mainhand:{id:"minecraft:diamond",count:1,components:{"minecraft:enchantments":{"merptown:explosion":2},"minecraft:item_model":"minecraft:air"}}},active_effects:[{id:"minecraft:invisibility",amplifier:0,duration:-1,show_particles:0b}]}
execute if entity @s[type=minecraft:snowball] run data modify entity @n[type=minecraft:wolf,tag=mine] Owner set from entity @s Owner
execute if entity @s[type=minecraft:player] run data modify entity @n[type=minecraft:wolf,tag=mine] Owner set from entity @s UUID
fill ~ ~-1 ~ ~ ~1 ~ air replace minecraft:polished_blackstone_pressure_plate
advancement revoke @s only merptown:mine