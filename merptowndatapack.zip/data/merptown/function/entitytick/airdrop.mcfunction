playsound minecraft:block.note_block.pling neutral @a ~ ~ ~ 20 2
execute as @a[distance=..2] run damage @s 10 minecraft:falling_block by @s
execute if block ~ ~-1 ~ #merptown:airdrop_spawnable run setblock ~ ~ ~ minecraft:green_shulker_box{LootTable:"merptown:chests/airdrop",CustomName:"Airdrop"}
execute if block ~ ~-1 ~ #merptown:airdrop_spawnable run kill @s
tp @s ~ ~-0.2 ~