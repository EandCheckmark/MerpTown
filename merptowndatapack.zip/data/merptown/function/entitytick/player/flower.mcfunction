execute store result score @s flower run clear @s #merptown:pottable 0
execute if score @s flower matches 0 run return fail
clear @s #merptown:pottable 1
loot give @s loot merptown:gameplay/flower
playsound minecraft:block.leaf_litter.step block @s