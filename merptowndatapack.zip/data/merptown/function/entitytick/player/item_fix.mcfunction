execute if items entity @s[gamemode=!creative] weapon.mainhand minecraft:crossbow[minecraft:charged_projectiles=[],minecraft:enchantments~[{enchantments:"minecraft:quick_charge",levels:5}]] if function merptown:item_check/ammo run function merptown:autoload
execute if items entity @s[gamemode=creative] weapon.mainhand minecraft:crossbow[minecraft:charged_projectiles=[],minecraft:enchantments~[{enchantments:"minecraft:quick_charge",levels:5}]] run function merptown:autoload
execute if items entity @s weapon.mainhand minecraft:crossbow[minecraft:item_model="merptown:rl",!minecraft:charged_projectiles=[]] run item modify entity @s weapon.mainhand merptown:item_fix/rl

execute if items entity @s weapon.offhand *[minecraft:custom_data~{Charm:1b}] run loot replace entity @s container.0 loot merptown:item_fix/melee/charmed
execute unless items entity @s weapon.offhand *[minecraft:custom_data~{Charm:1b}] if function merptown:item_check/melee/charmed run loot replace entity @s container.0 loot merptown:item_fix/melee/uncharmed

execute if function merptown:item_check/undyed run loot replace entity @s container.0 loot merptown:item_fix/redye