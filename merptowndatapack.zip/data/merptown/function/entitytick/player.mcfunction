function merptown:item_fix
execute if entity @s[gamemode=adventure] run function merptown:flower
execute if items entity @s weapon.offhand * unless items entity @s weapon.offhand *[minecraft:custom_data~{Charm:1b}] at @s run function merptown:offhand
execute if entity @s[gamemode=!spectator] run function merptown:traps

execute if score @s shoot matches 1.. run function merptown:recoil
execute if score @s salmonella matches 1.. run function merptown:salmonella

execute store result score @s ammo run clear @s #minecraft:arrows 0
execute if items entity @s[gamemode=!creative,scores={ammo=1..}] weapon.mainhand minecraft:crossbow[minecraft:charged_projectiles=[],minecraft:enchantments~[{enchantments:"minecraft:quick_charge",levels:5}]] run function merptown:autoload
execute if items entity @s[gamemode=creative] weapon.mainhand minecraft:crossbow[minecraft:charged_projectiles=[],minecraft:enchantments~[{enchantments:"minecraft:quick_charge",levels:5}]] run function merptown:autoload

execute if items entity @s armor.feet *[minecraft:custom_data~{Dolphin:1b}] run effect give @s minecraft:dolphins_grace 1 0 true
execute if entity @e[type=minecraft:marker,tag=spawn,distance=..5] run function merptown:antipvp
execute if entity @s[gamemode=!creative] if entity @e[type=minecraft:marker,tag=spawn,distance=..5] run clear @s
execute if entity @e[type=minecraft:marker,tag=tp,distance=..2] run function merptown:antipvp

execute if score @s hunger matches 19.. run attribute @s minecraft:movement_speed modifier remove merptown:hunger18
execute if score @s hunger matches 16.. run attribute @s minecraft:movement_speed modifier remove merptown:hunger15
execute if score @s hunger matches 11.. run attribute @s minecraft:movement_speed modifier remove merptown:hunger10
execute unless score @s hunger matches 19.. run attribute @s minecraft:movement_speed modifier add merptown:hunger18 -0.1 add_multiplied_total
execute unless score @s hunger matches 16.. run attribute @s minecraft:movement_speed modifier add merptown:hunger15 -0.1 add_multiplied_total
execute unless score @s hunger matches 11.. run attribute @s minecraft:movement_speed modifier add merptown:hunger10 -0.1 add_multiplied_total
attribute @s minecraft:waypoint_receive_range base set 0