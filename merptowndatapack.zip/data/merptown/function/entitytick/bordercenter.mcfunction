execute in minecraft:overworld run worldborder center ~ ~
execute if entity @e[type=minecraft:marker,tag=borderdest,distance=..0.15,limit=1] run return run tp @s @e[type=minecraft:marker,tag=borderdest,limit=1]
execute facing entity @e[type=minecraft:marker,tag=borderdest,limit=1] eyes run tp @s ^ ^ ^0.15