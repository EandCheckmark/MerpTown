execute if entity @s[tag=dropoffinit] run function merptown:bullet/dropoff/remove_drag
execute if entity @s[tag=dropoffinit] run return run tag @s remove dropoffinit
execute if entity @s[tag=dropoff0] run return run function merptown:bullet/dropoff/0
execute if entity @s[tag=dropoff1] run return run function merptown:bullet/dropoff/1
execute if entity @s[tag=dropoff2] run return run function merptown:bullet/dropoff/2
execute if entity @s[tag=dropoff3] run return run function merptown:bullet/dropoff/3
execute if entity @s[tag=dropoff4] run return run function merptown:bullet/dropoff/4
execute if entity @s[tag=dropoff5] run return run function merptown:bullet/dropoff/5