execute if block ~ ~ ~ minecraft:polished_blackstone_pressure_plate run function merptown:mine
execute if block ~ ~ ~ #merptown:traps run tag @s add flintclear
execute positioned ~-0.5 ~ ~ if block ~ ~ ~ minecraft:polished_blackstone_pressure_plate run function merptown:mine
execute if block ~-0.5 ~ ~ #merptown:traps run tag @s add flintclear
execute positioned ~0.5 ~ ~ if block ~ ~ ~ minecraft:polished_blackstone_pressure_plate run function merptown:mine
execute if block ~0.5 ~ ~ #merptown:traps run tag @s add flintclear
execute positioned ~ ~ ~-0.5 if block ~ ~ ~ minecraft:polished_blackstone_pressure_plate run function merptown:mine
execute if block ~ ~ ~-0.5 #merptown:traps run tag @s add flintclear
execute positioned ~ ~ ~0.5 if block ~ ~ ~ minecraft:polished_blackstone_pressure_plate run function merptown:mine
execute if block ~ ~ ~0.5 #merptown:traps run tag @s add flintclear
execute if block ~ ~ ~ #merptown:traps run fill ~ ~ ~ ~ ~ ~ air destroy
execute if block ~-0.5 ~ ~ #merptown:traps run fill ~-0.5 ~ ~ ~-0.5 ~ ~ air destroy
execute if block ~0.5 ~ ~ #merptown:traps run fill ~0.5 ~ ~ ~0.5 ~ ~ air destroy
execute if block ~ ~ ~-0.5 #merptown:traps run fill ~ ~ ~-0.5 ~ ~ ~-0.5 air destroy
execute if block ~ ~ ~0.5 #merptown:traps run fill ~ ~ ~0.5 ~ ~ ~0.5 air destroy
kill @s[tag=flintclear]