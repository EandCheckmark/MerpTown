function merptown:entitytick/bullet/dropoff



execute store result score @s bulletVelocityX run data get storage merptown:bullet velocity[0] 100
execute store result score @s bulletVelocityY run data get storage merptown:bullet velocity[1] 100
execute store result score @s bulletVelocityZ run data get storage merptown:bullet velocity[2] 100
scoreboard players operation @s bulletVelocityX *= @s bulletVelocityX
scoreboard players operation @s bulletVelocityY *= @s bulletVelocityY
scoreboard players operation @s bulletVelocityZ *= @s bulletVelocityZ
scoreboard players set @s bulletVelocity 0
scoreboard players operation @s bulletVelocity += @s bulletVelocityX
scoreboard players operation @s bulletVelocity += @s bulletVelocityY
scoreboard players operation @s bulletVelocity += @s bulletVelocityZ

execute if score @s bulletVelocity matches ..99999 at @s run function merptown:bullet/particle
execute if score @s bulletVelocity matches ..99999 at @s run particle minecraft:smoke ~ ~ ~ 0 0 0 0 3 force
execute unless score @s bulletVelocity matches 100000..640000 run return run kill @s



execute store result storage merptown:bullet particlex1 double 0.01 run data get storage merptown:bullet velocity[0] 25
execute store result storage merptown:bullet particley1 double 0.01 run data get storage merptown:bullet velocity[1] 25
execute store result storage merptown:bullet particlez1 double 0.01 run data get storage merptown:bullet velocity[2] 25
execute store result storage merptown:bullet particlex2 double 0.01 run data get storage merptown:bullet velocity[0] 50
execute store result storage merptown:bullet particley2 double 0.01 run data get storage merptown:bullet velocity[1] 50
execute store result storage merptown:bullet particlez2 double 0.01 run data get storage merptown:bullet velocity[2] 50
execute store result storage merptown:bullet particlex3 double 0.01 run data get storage merptown:bullet velocity[0] 75
execute store result storage merptown:bullet particley3 double 0.01 run data get storage merptown:bullet velocity[1] 75
execute store result storage merptown:bullet particlez3 double 0.01 run data get storage merptown:bullet velocity[2] 75

function merptown:bullet/particle
function merptown:bullet/particlemacro with storage merptown:bullet