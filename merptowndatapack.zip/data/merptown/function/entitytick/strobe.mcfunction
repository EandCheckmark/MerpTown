playsound minecraft:block.enchantment_table.use player @a ~ ~ ~ 1 2

execute unless predicate merptown:airstrike_tick run return fail

summon minecraft:snowball ~ ~20 ~ {Passengers:[{id:"minecraft:marker",Tags:["bomb"]}],Item:{id:"minecraft:snowball",count:1,components:{"minecraft:item_model":"merptown:bomb"}},Tags:["bomb"]}
execute positioned ~ ~20 ~ run data modify entity @n[type=minecraft:snowball,tag=bomb] Owner set from entity @s Owner
execute positioned ~ ~20 ~ run data modify entity @n[type=minecraft:marker,tag=bomb] data.Owner set from entity @s Owner

summon minecraft:snowball ~ ~40 ~ {Passengers:[{id:"minecraft:marker",Tags:["bomb"]}],Item:{id:"minecraft:snowball",count:1,components:{"minecraft:item_model":"merptown:bomb"}},Tags:["bomb"]}
execute positioned ~ ~40 ~ run data modify entity @n[type=minecraft:snowball,tag=bomb] Owner set from entity @s Owner
execute positioned ~ ~40 ~ run data modify entity @n[type=minecraft:marker,tag=bomb] data.Owner set from entity @s Owner