playsound minecraft:item.bundle.insert_fail master @s ~ ~ ~ 1 2
execute anchored eyes positioned ^ ^ ^ positioned ~ ~-0.3 ~ run loot spawn ~ ~ ~ loot merptown:offhand
item replace entity @s weapon.offhand with minecraft:air