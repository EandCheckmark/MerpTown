effect give @s minecraft:nausea 60 0 true
effect give @s minecraft:poison 10 1 true
title @s title {text:"You have food poisoning.",color:"dark_green"}
scoreboard players reset @s salmonella