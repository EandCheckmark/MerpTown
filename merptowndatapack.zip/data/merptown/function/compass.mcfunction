execute store result storage merptown:center x int 1 run data get entity @s Pos[0]
execute store result storage merptown:center z int 1 run data get entity @s Pos[2]
execute as @a run function merptown:compassmacro with storage merptown:center
execute as @e[type=minecraft:item] run function merptown:compassmacro with storage merptown:center