execute at @s run playsound minecraft:item.crossbow.loading_end player @a ~ ~ ~
execute unless function merptown:item_check/ammo run item modify entity @s weapon.mainhand merptown:item_fix/autoload_blank
execute if function merptown:item_check/ammo run item modify entity @s weapon.mainhand merptown:item_fix/autoload
execute if entity @s[gamemode=creative] run return 1
execute unless score @s automaticAmmo matches ..0 run return run scoreboard players remove @s automaticAmmo 1
scoreboard players set @s automaticAmmo 1
execute if items entity @s weapon.offhand #minecraft:arrows run return run item modify entity @s weapon.offhand merptown:remove_one
execute if items entity @s weapon.mainhand #minecraft:arrows run return run item modify entity @s weapon.mainhand merptown:remove_one
clear @s #minecraft:arrows 1
