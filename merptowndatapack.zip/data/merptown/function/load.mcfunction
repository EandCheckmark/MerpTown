scoreboard objectives add victory dummy
scoreboard objectives add active dummy
scoreboard objectives add hunger food
scoreboard objectives add salmonella minecraft.picked_up:minecraft.salmon
scoreboard objectives add shoot minecraft.used:minecraft.crossbow
scoreboard objectives add stun dummy
scoreboard objectives add playerCount dummy
scoreboard objectives add kills minecraft.custom:minecraft.player_kills Kills
scoreboard objectives add timer dummy
scoreboard objectives add bulletVelocityX dummy
scoreboard objectives add bulletVelocityY dummy
scoreboard objectives add bulletVelocityZ dummy
scoreboard objectives add bulletVelocity dummy
scoreboard objectives add ammo dummy
scoreboard objectives add automaticAmmo dummy
scoreboard objectives add flower dummy
scoreboard objectives add cloneProgress dummy
scoreboard objectives add start trigger
scoreboard objectives add startCount dummy
scoreboard objectives add requiredPlayers dummy

scoreboard players reset * start

bossbar add merptown:timer {text:"Timer",color:"blue"}
bossbar set merptown:timer max 14400
bossbar set merptown:timer color blue
bossbar set merptown:timer style notched_12

execute at @e[type=minecraft:marker,tag=spawn,limit=1] run setworldspawn ~ ~ ~ 0 0
worldborder damage buffer 0
worldborder damage amount 0.02
worldborder warning distance 0
worldborder warning time 0t
difficulty normal
function merptown:gamerules
execute unless entity @a run function merptown:game/prepare