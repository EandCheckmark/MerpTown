tag @s add rocket
data modify storage merptown:rocket velocity set from entity @s Motion
execute store result storage merptown:rocket velocity[0] double 0.0001 run data get storage merptown:rocket velocity[0] 15000
execute store result storage merptown:rocket velocity[1] double 0.0001 run data get storage merptown:rocket velocity[1] 15000
execute store result storage merptown:rocket velocity[2] double 0.0001 run data get storage merptown:rocket velocity[2] 15000
data modify entity @s Motion set from storage merptown:rocket velocity