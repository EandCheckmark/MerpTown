tag @e[type=minecraft:snowball,tag=!flint,tag=!grenade,tag=!bomb,tag=!airstrike,nbt={Item:{components:{"minecraft:item_model":"merptown:strobe"}}}] add airstrike
execute as @e[type=minecraft:snowball,tag=airstrike] at @s run function merptown:entitytick/strobe

execute as @e[type=minecraft:marker,tag=bomb] at @s unless predicate merptown:riding_snowball run function merptown:bomb

tag @e[type=minecraft:snowball,tag=!flint,tag=!grenade,tag=!bomb,tag=!airstrike,nbt={Item:{components:{"minecraft:item_model":"merptown:grenade"}}}] add grenade
execute as @e[type=minecraft:snowball,tag=grenade] unless predicate merptown:has_passenger at @s run summon minecraft:marker ~ ~ ~ {Tags:["grenade"],Invisible:1b,Marker:1b}
execute as @e[type=minecraft:snowball,tag=grenade] unless predicate merptown:has_passenger at @s run data modify entity @n[type=marker,tag=grenade] data.Owner set from entity @s Owner
execute as @e[type=minecraft:snowball,tag=grenade] unless predicate merptown:has_passenger at @s run ride @n[type=minecraft:marker,tag=grenade] mount @s

execute as @e[type=minecraft:marker,tag=grenade] at @s unless predicate merptown:riding_snowball run function merptown:grenade

execute as @e[type=minecraft:area_effect_cloud] run data merge entity @s {Duration:200,RadiusPerTick:0f,RadiusOnUse:0f}

tag @e[type=minecraft:snowball,tag=!flint,tag=!grenade,tag=!bomb,tag=!airstrike,nbt={Item:{components:{"minecraft:item_model":"minecraft:flint"}}}] add flint
execute as @e[type=minecraft:snowball,tag=flint] at @s run function merptown:entitytick/flint