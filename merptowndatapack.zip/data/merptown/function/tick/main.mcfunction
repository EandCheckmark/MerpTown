effect give @a[gamemode=creative] minecraft:strength 1 255 true
gamemode adventure @a[gamemode=survival]
scoreboard players reset @a[gamemode=spectator,scores={stun=1..}] stun
scoreboard players remove @a[scores={stun=1..}] stun 1
scoreboard players set @a[scores={start=2..}] start 1
scoreboard players set @a[scores={start=..-1}] start 0
execute as @a[scores={hunger=19..}] run attribute @s minecraft:movement_speed modifier remove merptown:hunger18
execute as @a[scores={hunger=16..}] run attribute @s minecraft:movement_speed modifier remove merptown:hunger15
execute as @a[scores={hunger=11..}] run attribute @s minecraft:movement_speed modifier remove merptown:hunger10
execute as @a[scores={hunger=..18}] run attribute @s minecraft:movement_speed modifier add merptown:hunger18 -0.1 add_multiplied_total
execute as @a[scores={hunger=..15}] run attribute @s minecraft:movement_speed modifier add merptown:hunger15 -0.1 add_multiplied_total
execute as @a[scores={hunger=..10}] run attribute @s minecraft:movement_speed modifier add merptown:hunger10 -0.1 add_multiplied_total
execute as @a at @s run function merptown:entitytick/player

execute as @e[type=minecraft:block_display,tag=airdrop] at @s run function merptown:entitytick/airdrop
execute as @e[type=minecraft:marker,tag=bordercenter,limit=1] at @s run function merptown:entitytick/bordercenter
execute at @e[type=minecraft:marker,tag=spawn,limit=1] run spawnpoint @a ~ ~ ~
execute as @e[type=#minecraft:arrows] at @s run function merptown:entitytick/bullet
execute as @e[type=minecraft:firework_rocket,tag=!rocket,nbt={ShotAtAngle:1b}] run function merptown:rocket

kill @e[type=minecraft:experience_orb]

stopsound @a music
stopsound @a * minecraft:ambient.cave
recipe take @a *
xp set @a 0 levels
xp set @a 0 points

execute at @e[type=minecraft:block_display,tag=airdrop] run particle minecraft:dust{color:[0.000,0.500,0.000],scale:4} ~ ~4 ~ 2 2 2 0 10 force
execute at @e[type=minecraft:area_effect_cloud] run particle minecraft:campfire_cosy_smoke ~ ~0.5 ~ 1.5 1.5 1.5 0 20 force
execute at @e[type=minecraft:firework_rocket,tag=rocket] run particle minecraft:campfire_cosy_smoke ~ ~ ~ 0.2 0.2 0.2 0 10 force
execute as @e[type=minecraft:item] if items entity @s contents minecraft:salmon at @s run particle minecraft:sneeze ~ ~0.5 ~ 0 0 0 0.01 1 force