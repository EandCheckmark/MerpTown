execute unless entity @a if score [active] active matches 0.. run function merptown:game/prepare

execute store result score [playercount] playerCount if entity @a[gamemode=adventure]

execute if score [active] active matches 1 run title @a actionbar [{text:"Players left: ",color:"aqua"},{score:{name:"[playercount]",objective:"playerCount"},color:"red"}]

execute if score [playercount] playerCount matches 1 if score [active] active matches 1 run schedule function merptown:game/prepare 10s
execute if score [playercount] playerCount matches 1 if score [active] active matches 1 as @a[gamemode=adventure] at @s run function merptown:victory
execute if score [timer] timer matches 0 if score [playercount] playerCount matches 2.. if score [active] active matches 1 run schedule function merptown:game/prepare 10s
execute if score [timer] timer matches 0 if score [playercount] playerCount matches 2.. if score [active] active matches 1 as @a[gamemode=adventure] at @s run function merptown:draw

execute if score [active] active matches ..-1 run scoreboard players reset * victory
execute if score [active] active matches 0 as @a[gamemode=adventure] unless score @s victory matches 1 run kill @s
execute if score [active] active matches 0.. as @a[gamemode=adventure] at @s unless predicate merptown:in_map if score [timer] timer matches ..14380 run gamemode spectator @s
execute if score [active] active matches 0.. as @a[gamemode=spectator] at @s unless predicate merptown:in_map at @e[tag=bordercenter] run tp @s ~ 100 ~
execute if score [active] active matches ..-1 as @a[gamemode=adventure] at @s if predicate merptown:in_map run function merptown:tp/spawn

execute if score [active] active matches 0.. run function merptown:map/check
execute if score [active] active matches -1 run function merptown:startcheck


