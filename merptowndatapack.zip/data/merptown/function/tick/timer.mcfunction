execute if score [timer] timer matches 7200 as @e[type=minecraft:marker,tag=borderdest,limit=1] at @s run function merptown:timer/border384

execute if score [timer] timer matches 4800 as @e[type=minecraft:marker,tag=borderdest,limit=1] at @s run function merptown:timer/border256

execute if score [timer] timer matches 2400 as @e[type=minecraft:marker,tag=borderdest,limit=1] at @s run function merptown:timer/border128

execute if score [timer] timer matches 3600 as @e[type=minecraft:marker,tag=borderdest,limit=1] at @s run function merptown:timer/airdrop1

execute if score [timer] timer matches 1200 as @e[type=minecraft:marker,tag=borderdest,limit=1] at @s run function merptown:timer/airdrop2

execute if score [timer] timer matches ..0 run bossbar set merptown:timer visible false
execute if score [timer] timer matches 1.. run bossbar set merptown:timer visible true

execute if score [timer] timer matches ..-1 run scoreboard players set [timer] timer 0
execute if score [timer] timer matches 1.. run scoreboard players remove [timer] timer 1
execute store result bossbar merptown:timer value run scoreboard players get [timer] timer
bossbar set merptown:timer players @a