execute if predicate merptown:is_sneaking store result storage merptown:shoot recoil double 0.5 run data get entity @s SelectedItem.components."minecraft:enchantments"."minecraft:unbreaking"
execute unless predicate merptown:is_sneaking store result storage merptown:shoot recoil int 1 run data get entity @s SelectedItem.components."minecraft:enchantments"."minecraft:unbreaking"
function merptown:recoilmacro with storage merptown:shoot
execute anchored eyes run particle minecraft:block{block_state:"gold_block"} ^ ^-0.1 ^0.5 0 0 0 0 1
advancement revoke @s only merptown:shoot