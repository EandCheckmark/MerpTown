scoreboard players enable @a start
execute store result storage merptown:start players int 1 if entity @a
execute store result storage merptown:start half int 1 run data get storage merptown:start players 0.5
execute store result score [requiredplayers] requiredPlayers run data get storage merptown:start half 1
execute unless score [requiredplayers] requiredPlayers matches 3.. run scoreboard players set [requiredplayers] requiredPlayers 3
execute store result storage merptown:start required int 1 run scoreboard players get [requiredplayers] requiredPlayers
execute store result score [startcount] startCount if entity @a[scores={start=1}]

title @a actionbar [{color:"aqua",text:"Players ready: "},{color:"red",score:{name:"[startcount]",objective:"startCount"}},{color:"red",text:"/"},{color:"red",score:{name:"[requiredplayers]",objective:"requiredPlayers"}},{color:"aqua",text:" ("},{color:"green",text:"/trigger start"},{color:"aqua",text:" to mark yourself ready)"}]
scoreboard players display numberformat @a[scores={start=0}] start fixed [{text:"X ",color:"dark_red"},{text:"Not Ready ",color:"red"}]
scoreboard players display numberformat @a[scores={start=1}] start fixed [{text:"✔ ",color:"dark_green"},{text:"Ready ",color:"green"}]

function merptown:startmacro with storage merptown:start