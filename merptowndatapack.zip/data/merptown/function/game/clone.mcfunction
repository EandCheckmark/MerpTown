execute unless blocks ~ -500 ~ ~15 -430 ~15 ~ ~ ~ all run clone ~ -500 ~ ~15 -430 ~15 ~ ~ ~ strict
scoreboard players add @s cloneProgress 1
title @a actionbar [{"color":"aqua","text":"Map reset progress: "},{"color":"red","score":{"name":"@s","objective":"cloneProgress"}},{"color":"red","text":"/1024"}]
tp @s ~16 ~ ~