schedule clear merptown:game/prepare
schedule clear merptown:game/initiate
schedule clear merptown:game/start

schedule clear merptown:game/countdown/3
schedule clear merptown:game/countdown/2
schedule clear merptown:game/countdown/1

tellraw @a [{"text":"\n"},{"color":"aqua","text":"MerpTown"},{"color":"dark_aqua","text":" // "},{"color":"green","text":"Game starting in 30 seconds."},{"text":"\n"}]

scoreboard players set [active] active -2
scoreboard players reset * start
scoreboard objectives setdisplay list

schedule function merptown:game/countdown/3 27s
schedule function merptown:game/countdown/2 28s
schedule function merptown:game/countdown/1 29s
schedule function merptown:game/start 30s