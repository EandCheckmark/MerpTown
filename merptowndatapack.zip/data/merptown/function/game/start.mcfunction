schedule clear merptown:game/prepare
schedule clear merptown:game/initiate
schedule clear merptown:game/start

schedule clear merptown:game/countdown/3
schedule clear merptown:game/countdown/2
schedule clear merptown:game/countdown/1

time of minecraft:overworld set 0
gamemode adventure @a
clear @a
title @a times 5t 15t 5t

scoreboard players set [timer] timer 14400
scoreboard players set [active] active 1
scoreboard players set @a automaticAmmo 2
scoreboard players reset * kills
scoreboard players reset * start
scoreboard objectives setdisplay list kills

kill @e[type=minecraft:item]
kill @e[type=#minecraft:arrows]
kill @e[tag=sandbox]

loot replace entity @a[tag=Melee] armor.legs loot merptown:items/perks/melee
loot replace entity @a[tag=Rush] armor.legs loot merptown:items/perks/rush
loot replace entity @a[tag=Heavy] armor.legs loot merptown:items/perks/heavy
loot replace entity @a[tag=Reinforced] armor.legs loot merptown:items/perks/reinforced
loot replace entity @a[tag=Gear] armor.legs loot merptown:items/perks/gear
loot replace entity @a[tag=Light] armor.legs loot merptown:items/perks/light
loot replace entity @a[tag=Lucky] armor.legs loot merptown:items/perks/lucky
loot replace entity @a[tag=Health] armor.legs loot merptown:items/perks/health
loot replace entity @a[tag=Awareness] armor.legs loot merptown:items/perks/awareness
execute as @a unless items entity @s armor.legs *[minecraft:custom_data~{Gear:1b}] run loot give @s loot merptown:gameplay/game_start
execute as @a if items entity @s armor.legs *[minecraft:custom_data~{Gear:1b}] run loot give @s loot merptown:gameplay/game_start_alt

tag @a remove Melee
tag @a remove Rush
tag @a remove Heavy
tag @a remove Reinforced
tag @a remove Gear
tag @a remove Light
tag @a remove Lucky
tag @a remove Health
tag @a remove Awareness

effect clear @a
effect give @a minecraft:saturation 1 19 true
effect give @a minecraft:instant_health 1 19 true
effect give @a minecraft:hunger infinite 2 true

execute at @e[type=minecraft:marker,tag=bordercenter,limit=1] positioned ~0.5 ~ ~0.5 positioned over world_surface run playsound minecraft:block.enchantment_table.use ambient @a ~ ~100 ~ 20 0
execute at @e[type=minecraft:marker,tag=bordercenter,limit=1] positioned ~0.5 ~ ~0.5 positioned over world_surface run playsound minecraft:block.note_block.chime ambient @a ~ ~100 ~ 20 0
execute at @e[type=minecraft:marker,tag=bordercenter,limit=1] run spreadplayers ~ ~ 32 256 under 80 false @a
execute as @e[type=minecraft:marker,tag=borderdest,limit=1] at @s run function merptown:compass

title @a title {text:"GAME START",color:"dark_aqua",bold:true}
tellraw @a [{"text":"\n"},{"color":"aqua","text":"MerpTown"},{"color":"dark_aqua","text":" // "},{"color":"green","text":"The game has started."},{"text":"\n"}]