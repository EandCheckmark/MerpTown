schedule clear merptown:game/prepare
schedule clear merptown:game/initiate
schedule clear merptown:game/start

schedule clear merptown:game/countdown/3
schedule clear merptown:game/countdown/2
schedule clear merptown:game/countdown/1

tellraw @a [{"text":"\n"},{"color":"aqua","text":"MerpTown"},{"color":"dark_aqua","text":" // "},{"color":"green","text":"Preparing next game..."},{"text":"\n"}]

scoreboard players set [timer] timer 0
scoreboard players set [active] active -2
scoreboard players reset * victory
scoreboard players reset * kills
scoreboard players reset * start
scoreboard objectives setdisplay list

tp @e[tag=borderdest,limit=1] @e[tag=border512,limit=1]
tp @e[tag=borderdest128,limit=1] @e[tag=border128,sort=random,limit=1]
execute at @e[tag=borderdest128,limit=1] run tp @e[tag=borderdest256,limit=1] @e[distance=..100,tag=border256,sort=random,limit=1]
execute at @e[tag=borderdest256,limit=1] run tp @e[tag=borderdest384,limit=1] @e[distance=..100,tag=border384,sort=random,limit=1]
tp @e[tag=bordercenter,limit=1] @e[tag=border512,limit=1]
execute in minecraft:overworld run worldborder set 512 0t

tp @a @e[tag=spawn,limit=1]
gamemode adventure @a
clear @a
effect clear @a
effect give @a minecraft:saturation 1 19
effect give @a minecraft:instant_health 1 19
title @a clear
tag @a remove Melee
tag @a remove Rush
tag @a remove Heavy
tag @a remove Reinforced
tag @a remove Gear
tag @a remove Light
tag @a remove Lucky
tag @a remove Health
tag @a remove Brute

kill @e[type=#merptown:clear]
kill @e[type=minecraft:marker,tag=!border,tag=!spawn,tag=!tp,tag=!food]
kill @e[tag=airdrop]

execute at @e[tag=bordercenter,limit=1] positioned over world_surface as @e[tag=chicken] run summon minecraft:chicken ~ ~ ~ {Age:0}
execute at @e[tag=bordercenter,limit=1] positioned over world_surface as @e[tag=pig] run summon minecraft:pig ~ ~ ~ {Age:0}
execute at @e[tag=bordercenter,limit=1] positioned over world_surface as @e[tag=sheep] run summon minecraft:sheep ~ ~ ~ {Age:0}
execute at @e[tag=bordercenter,limit=1] positioned over world_surface as @e[tag=cow] run summon minecraft:cow ~ ~ ~ {Age:0}
execute at @e[tag=bordercenter,limit=1] run spreadplayers ~ ~ 32 256 under 80 false @e[type=#merptown:food]

schedule function merptown:game/clone/start 1t append