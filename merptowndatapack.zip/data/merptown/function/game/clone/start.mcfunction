kill @e[type=marker,tag=clone]
summon minecraft:marker -64 50 -64 {Tags:["clone"]}
scoreboard players set @e[type=minecraft:marker,tag=clone,limit=1] cloneProgress 0
schedule function merptown:game/clone/repeat 1t append