execute unless entity @e[type=minecraft:marker,tag=clone,limit=1] run return fail
execute as @e[type=minecraft:marker,tag=clone,limit=1] at @s run function merptown:game/clone
execute as @e[type=minecraft:marker,tag=clone,limit=1] at @s unless block ~ -501 ~ minecraft:bedrock run tp @s -64 ~ ~16
execute as @e[type=minecraft:marker,tag=clone,limit=1] at @s unless block ~ -501 ~ minecraft:bedrock run return run schedule function merptown:game/clone/final 1t append
schedule function merptown:game/clone/repeat 1t append