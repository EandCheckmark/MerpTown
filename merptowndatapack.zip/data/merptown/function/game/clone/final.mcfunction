kill @e[type=minecraft:marker,tag=clone,limit=1]
tellraw @a [{"text":"\n"},{"color":"aqua","text":"MerpTown"},{"color":"dark_aqua","text":" // "},{"color":"green","text":"The next game is ready."},{"text":"\n"}]

scoreboard players set [active] active -1
scoreboard objectives setdisplay list start