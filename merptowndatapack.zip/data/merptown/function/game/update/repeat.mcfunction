execute unless entity @e[type=minecraft:marker,tag=update,limit=1] run return fail
execute as @e[type=minecraft:marker,tag=update,limit=1] at @s run function merptown:game/update/clone
execute as @e[type=minecraft:marker,tag=update,limit=1] at @s in minecraft:the_end unless block ~ 49 ~ minecraft:bedrock in minecraft:overworld run tp @s -64 ~ ~16
execute as @e[type=minecraft:marker,tag=update,limit=1] at @s in minecraft:the_end unless block ~ 49 ~ minecraft:bedrock in minecraft:overworld run return run function merptown:update/final
schedule function merptown:game/update/repeat 1t append