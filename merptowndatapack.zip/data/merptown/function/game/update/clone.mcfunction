clone from minecraft:the_end ~ ~ ~ ~15 120 ~15 ~ -500 ~ strict
scoreboard players add @s cloneProgress 1
title @a actionbar [{"color":"aqua","text":"Map update progress: "},{"color":"red","score":{"name":"@s","objective":"cloneProgress"}},{"color":"red","text":"/1024"}]
tp @s ~16 ~ ~