kill @e[type=minecraft:marker,tag=update,limit=1]
execute in minecraft:the_end run forceload remove all