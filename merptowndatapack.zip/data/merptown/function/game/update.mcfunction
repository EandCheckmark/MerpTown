kill @e[type=marker,tag=update]
execute in minecraft:the_end run forceload add -64 -64 191 191
execute in minecraft:the_end run forceload add 192 -64 447 191
execute in minecraft:the_end run forceload add -64 192 191 447
execute in minecraft:the_end run forceload add 192 192 447 447
summon minecraft:marker -64 50 -64 {Tags:["update"]}
scoreboard players set @e[type=minecraft:marker,tag=update,limit=1] cloneProgress 0
schedule function merptown:game/update/repeat 1t append