gamerule show_death_messages false
tp @s 0 -100 0
kill @s
gamerule show_death_messages true