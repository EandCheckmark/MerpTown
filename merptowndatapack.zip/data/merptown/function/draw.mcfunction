title @s title {text:"DRAW",color:"yellow",bold:true}
playsound minecraft:ui.toast.in master @a ~ ~ ~
effect give @s minecraft:resistance infinite 4 true
scoreboard players set @s victory 1
scoreboard players set [timer] timer 0
scoreboard players set [active] active 0