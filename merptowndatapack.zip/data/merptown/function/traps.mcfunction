execute if block ~ ~0.5 ~ minecraft:polished_blackstone_pressure_plate run function merptown:mine
execute if block ~ ~0.5 ~ minecraft:light_weighted_pressure_plate run function merptown:stunner
execute if block ~ ~0.5 ~ minecraft:stone_button run function merptown:pebble
execute if score @s stun matches 1.. run tp @s @s