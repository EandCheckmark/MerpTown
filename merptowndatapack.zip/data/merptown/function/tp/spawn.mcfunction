execute at @e[type=minecraft:marker,tag=spawn,limit=1] run tp @s ~ ~ ~ ~ ~
clear @s
effect clear @s
function merptown:heal