execute at @e[type=minecraft:marker,tag=sandboxtp,limit=1] run tp @s ~ ~ ~ ~ ~
function merptown:heal