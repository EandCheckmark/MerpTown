execute at @e[type=minecraft:marker,tag=tutorialtp,limit=1] run tp @s ~ ~ ~ ~ ~
effect give @s minecraft:resistance infinite 4 true
effect give @s minecraft:weakness infinite 255 true
function merptown:heal