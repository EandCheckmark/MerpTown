execute at @e[type=minecraft:marker,tag=pvptp,limit=1] run tp @s ~ ~ ~ ~ ~
function merptown:heal
loot give @s loot merptown:gameplay/pvp
effect give @s minecraft:hunger infinite 2 true