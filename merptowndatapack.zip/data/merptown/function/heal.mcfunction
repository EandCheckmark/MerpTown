effect give @s minecraft:instant_health 1 19 true
effect give @s minecraft:saturation 1 19 true