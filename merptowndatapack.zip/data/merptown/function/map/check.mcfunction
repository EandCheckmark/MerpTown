function merptown:map/bunker_inferno/lockcheck
function merptown:map/bunker_river/lockcheck