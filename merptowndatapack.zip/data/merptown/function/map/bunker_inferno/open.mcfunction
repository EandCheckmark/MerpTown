fill 402 60 240 402 62 242 minecraft:air destroy
playsound minecraft:entity.zombie.break_wooden_door master @a 402 61 241 15 0
playsound minecraft:block.iron_door.open master @a 402 61 241 15 0