effect give @s minecraft:resistance 1 4 true
effect give @s minecraft:weakness 1 255 true
function merptown:heal