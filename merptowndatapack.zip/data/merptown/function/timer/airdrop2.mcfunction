execute positioned ~-0.5 ~ ~-0.5 positioned over world_surface run summon block_display ~ ~100 ~ {Glowing:1b,Tags:["airdrop"],CustomName:"Airdrop",glow_color_override:6192150,transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[-0.5f,0f,-0.5f],scale:[1f,1f,1f]},block_state:{Name:"minecraft:green_shulker_box"}}
execute positioned ~-0.5 ~ ~-0.5 positioned over world_surface run playsound minecraft:block.enchantment_table.use ambient @a ~ ~100 ~ 20 0
title @a title {text:"AIRDROP",color:"green",bold:true}
tellraw @a [{"text":"\n"},{"color":"aqua","text":"MerpTown"},{"color":"dark_aqua","text":" // "},{"color":"green","text":"An airdrop has spawned."},{"text":"\n"}]
function merptown:compass