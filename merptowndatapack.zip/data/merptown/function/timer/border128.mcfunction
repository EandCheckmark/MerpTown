worldborder set 128 60s
tp @s @e[type=minecraft:marker,tag=borderdest128,limit=1]
execute positioned over world_surface run playsound minecraft:block.enchantment_table.use ambient @a ~ ~100 ~ 20 0
title @a title {text:"BORDER",color:"red",bold:true}
tellraw @a [{"text":"\n"},{"color":"aqua","text":"MerpTown"},{"color":"dark_aqua","text":" // "},{"color":"green","text":"Border closing to 128 blocks."},{"text":"\n"}]
function merptown:compass