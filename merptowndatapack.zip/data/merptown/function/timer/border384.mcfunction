worldborder set 384 60s
tp @s @e[type=minecraft:marker,tag=borderdest384,limit=1]
execute positioned over world_surface run playsound minecraft:block.enchantment_table.use ambient @a ~ ~100 ~ 20 0
title @a title {text:"BORDER",color:"red",bold:true}
execute store result score @s tellrawX run data get entity @s Pos[0]
execute store result score @s tellrawZ run data get entity @s Pos[2]
tellraw @a [{"text":"\n"},{"color":"aqua","text":"MerpTown"},{"color":"dark_aqua","text":" // "},{"color":"green","text":"Border closing to 384 blocks."},{"text":"\n"}]
function merptown:compass